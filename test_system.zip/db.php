<?php
$hostname = "fdb34.awardspace.net";
$username = "3931225_sindski";
$password = "ML5*G^-p5%^C#Uf7";
$dbname = "3931225_sindski";
$conn = new mysqli($hostname, $username, $password, $dbname);
/*
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfull ";
*/
?>